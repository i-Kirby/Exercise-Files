﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ExploreCalifornia.DataAccess;
using ExploreCalifornia.DataAccess.Models;
using ExploreCalifornia.DTOs;

namespace ExploreCalifornia.Controllers
{
    [Authorize]
    [RoutePrefix("api/tour")]
    public class TourController : ApiController
    {
        private readonly AppDataContext _context = new AppDataContext();

        /// <summary>
        /// Gets a list of all tours
        /// </summary>
        /// <param name="freeOnly">Show free tours only?</param>
        /// <returns>List of all matching tours</returns>
        [HttpGet]
        public List<TourDto> GetAllTours(bool freeOnly = false)
        {
            var query = _context.Tours
                //.AsQueryable();
                .Select(i => new TourDto
                {
                    Name = i.Name,
                    Description = i.Description,
                    Price = i.Price
                });

            if (freeOnly) query = query.Where(i => i.Price == 0.0m);
                
            return query.ToList();
        }

        [Route("{id:identity}")]
        public TourDto Get(int id)
        {
            var item = _context.Tours
                .Where(i => i.TourId == id)
                .Select(i => new TourDto
                {
                    Name = i.Name,
                    Description = i.Description,
                    Price = i.Price
                })
                .FirstOrDefault();

            return item;
        }

        [Route("{name}")]
        public TourDto Get(string name)
        {
            var item = _context.Tours
                .Where(i => i.Name.Contains(name))
                .Select(i => new TourDto
                {
                    Name = i.Name,
                    Description = i.Description,
                    Price = i.Price
                })
                .FirstOrDefault();

            return item;
        }

        public List<TourDto> PostSearch(TourSearchRequestDto request)
        {
            if (request.MinPrice > request.MaxPrice)
                throw new HttpResponseException(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent("MinPrice must be less than MaxPrice")
                });
            
            var query = _context.Tours
                .Select(i => new TourDto
                {
                    Name = i.Name,
                    Description = i.Description,
                    Price = i.Price
                }).Where(i => i.Price <= request.MaxPrice 
                              && i.Price >= request.MinPrice);

            return query.ToList();
        }
        
        public IHttpActionResult Put(int id, TourDto dto)
        {
            return Ok($"Put {id} {dto.Name}");
        }

        public IHttpActionResult Patch()
        {
            return Ok("Patch");
        }

        public IHttpActionResult Delete()
        {
            return Ok("Delete");
        }
    }
}