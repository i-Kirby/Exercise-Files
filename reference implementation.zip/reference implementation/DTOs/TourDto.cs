﻿namespace ExploreCalifornia.DTOs
{
    public class TourDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
    }
}