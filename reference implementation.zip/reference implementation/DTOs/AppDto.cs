﻿using System;

namespace ExploreCalifornia.DTOs
{
    public class AppDto
    {
        public string Name { get; set; }
        public DateTime TokenExpiration { get; set; }
    }
}